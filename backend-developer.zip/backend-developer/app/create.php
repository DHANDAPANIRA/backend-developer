<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json;");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../app/products.php';
$item=  array();
    $database = new Database();
    $db = $database->getConnection();
    $item = new Products($db);
    $datas = trim(file_get_contents('php://input'));
//$data = json_decode($datas, true);
   $data= json_decode($datas);

    $item['id'] = $data->id;
    $item['sku'] = $data->sku;
    $item['title'] = $data->title;
    $item['variant_id'] = $data->variant_id;
    $item['created_at'] = date('Y-m-d H:i:s');
     
    if($item->createProducts($item)){
        echo 'Product Added successfully.';
    } else{
        echo 'Product could not be Added.';
    }
?>
