<?php
session_start();
use App\Http\Requests;
    class Products{

        // Connection
        private $conn;

        // Table
        private $db_table = "products";
        // Columns
        public $id;
        public $sku;
        public $title;
	    public $created_at;

       // Table
        private $db_table1 = "variants";
	    public $v_id;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getProducts(){
            $sqlQuery = "SELECT id, sku, title, created_at FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createProducts($item){

            $sqlQuery=("INSERT INTO ". $this->db_table ." (`id`, `sku`, `title`, `created_at`)
                VALUES (".$item->id.", ".$item->sku.", ".$item->title.", ".$item->created_at.")"); 
                
            $query2 = ("INSERT INTO ". $this->db_table1 ." (`id`) VALUES(".$item->variant_id.")");

            $stmt = $this->conn->prepare($sqlQuery);
            $stmt2 = $this->conn->prepare($query2);
         
            if($stmt->execute() & $stmt2->execute() ){
               return true;
            }
            return false;
        }

        // READ single
        public function getSingleProducts(){
            
        }        

        // UPDATE
        public function updateProducts(){
            
        }

        // DELETE
        function deleteProducts(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>
